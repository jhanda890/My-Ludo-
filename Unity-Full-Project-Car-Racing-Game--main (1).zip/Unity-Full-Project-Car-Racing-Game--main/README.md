# Unity-Full-Project-Car-Racing-Game-


![pic](pic.png)


This project was done by me for one of my campus projects and here the full project has been uploaded as a Mediafire Link so that it can be downloaded only and anyone can download it by following the link below.

Mediafire Link :  https://www.mediafire.com/file/axg48uoidiyzwrf/Project.zip/file (Compressed Size 1.2GB )

Zip File Password : 1490

Unity Editor Version :- Unity 2021.3.25f1


Note :- MUST READ THIS .....👇

"There may be small mistakes in this project, for example, there are small mistakes in car movements and car sounds.  You just have to open it and you have full freedom to change the things you want and make it as you like"

All the Coding Scripts related to this project have been uploaded above and they are also included in the Full Project Zip.
